"""Native geometry for trial crops; AI assigns ownership, never coordinates."""
import fitz
import re
import unicodedata
import csv
import io
import os
import shutil
import subprocess
from statistics import median
from difflib import SequenceMatcher


def extract_blocks(page):
    blocks = []
    for block in page.get_text('dict')['blocks']:
        spans = [s for line in block.get('lines', []) for s in line['spans'] if s['text'].strip()]
        blocks.append({'id': len(blocks), 'kind': 'text' if block['type'] == 0 else 'image',
                       'bbox': list(block['bbox']),
                       'font_min': min((s['size'] for s in spans), default=0),
                       'font_max': max((s['size'] for s in spans), default=0),
                       'text': ' '.join(s['text'] for line in block.get('lines', []) for s in line['spans'])})
    if any(b['kind'] == 'image' and
           (fitz.Rect(b['bbox']) & page.rect).get_area() >= page.rect.get_area() * .9
           for b in blocks):
        from raster_layout import extract_raster_blocks
        return extract_raster_blocks(page)
    # Long page rules connect otherwise separate drawing clusters. Ignore those
    # spanning shapes when discovering local vector artwork, not when rendering.
    drawings = [d for d in page.get_drawings()
                if d['rect'].width < page.rect.width * .65
                and d['rect'].height < page.rect.height * .65]
    for rect in page.cluster_drawings(drawings=drawings):
        if rect.width <= 30 or rect.height <= 12:
            continue
        if any(b['kind'] == 'image' and (rect & fitz.Rect(b['bbox'])).get_area() >= rect.get_area() * .99
               for b in blocks):
            continue
        blocks.append({'id': len(blocks), 'kind': 'vector_artwork', 'bbox': list(rect), 'text': ''})
    damaged = [b for b in blocks if b['kind'] == 'text' and damaged_text(b['text'])]
    if damaged or not any(b['kind'] == 'text' for b in blocks):
        words = ocr_words(page)
        if not words:
            raise ValueError('OCR returned no words for a page requiring text recovery.')
        if damaged:
            for block in damaged:
                rect = fitz.Rect(block['bbox'])
                recovered = [w['text'] for w in words
                             if rect.contains(fitz.Point(w['cx'], w['cy']))]
                if not recovered:
                    recovered = [ocr_region(page, rect)]
                if not recovered[0].strip():
                    raise ValueError(f"OCR could not recover native block {block['id']}.")
                block['text'] = ' '.join(recovered)
                block['text_source'] = 'tesseract_ocr'
        else:
            # A full-page scan image is a rendering surface, not an article region.
            blocks = []
            groups = {}
            for word in words:
                groups.setdefault(word['group'], []).append(word)
            for group in groups.values():
                rect = fitz.Rect(group[0]['bbox'])
                for word in group[1:]:
                    rect |= fitz.Rect(word['bbox'])
                blocks.append({'id': len(blocks), 'kind': 'text', 'bbox': list(rect),
                               'font_min': 0, 'font_max': 0, 'text_source': 'tesseract_ocr',
                               'text': ' '.join(w['text'] for w in group)})
            # Image-only regions require a layout detector; do not silently omit them.
            raise ValueError('Scanned page requires image-region layout detection; OCR text recovered but crops withheld.')
    return blocks


def damaged_text(text):
    compact = ''.join(c for c in text if not c.isspace())
    bad = sum(unicodedata.category(c) == 'Cc' or c == '\ufffd' for c in compact)
    # Isolated dingbats are common in otherwise usable newspaper text.
    return bool(compact) and bad >= 3 and bad / len(compact) > .05


def ocr_words(page):
    executable = os.environ.get('TESSERACT_CMD') or shutil.which('tesseract')
    if not executable and os.path.isfile(r'C:\Program Files\Tesseract-OCR\tesseract.exe'):
        executable = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    if not executable:
        raise ValueError('Text recovery requires Tesseract OCR; set TESSERACT_CMD.')
    scale = 200 / 72
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
    result = subprocess.run([executable, 'stdin', 'stdout', '-l', 'eng', '--psm', '3', 'tsv'],
                            input=pix.tobytes('png'), capture_output=True, timeout=180)
    if result.returncode:
        raise ValueError('Tesseract OCR failed during text recovery.')
    words = []
    for row in csv.DictReader(io.StringIO(result.stdout.decode('utf-8')), delimiter='\t'):
        if row['level'] != '5' or not row.get('text', '').strip():
            continue
        x, y, w, h = [float(row[k]) / scale for k in ('left', 'top', 'width', 'height')]
        words.append({'text': row['text'], 'bbox': [x, y, x+w, y+h],
                      'cx': x+w/2, 'cy': y+h/2,
                      'group': (row['block_num'], row['par_num'])})
    return words


def ocr_region(page, rect):
    executable = os.environ.get('TESSERACT_CMD') or shutil.which('tesseract')
    if not executable:
        executable = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3), clip=rect, alpha=False)
    result = subprocess.run([executable, 'stdin', 'stdout', '-l', 'eng', '--psm', '6'],
                            input=pix.tobytes('png'), capture_output=True, timeout=30)
    return result.stdout.decode('utf-8').strip() if result.returncode == 0 else ''


EXCLUSIONS = ['exclude:masthead', 'exclude:teaser', 'exclude:advertisement', 'exclude:print_mark']


def normalized(text):
    return ' '.join(re.findall(r'\w+', unicodedata.normalize('NFKC', text).casefold()))


def headline_matches(headline, title):
    a, b = normalized(headline), normalized(title)
    if not a or not b:
        return False
    if a == b:
        return True
    short, long = sorted((a, b), key=len)
    substantial = len(short.split()) >= 2 and len(short) >= 8 and len(short) >= len(long)*.55
    return (substantial and short in long) or SequenceMatcher(None, a, b).ratio() >= .92


def headline_evidence(blocks):
    """Conservative typography/teaser hints, not a universal article detector."""
    text = [b for b in blocks if b['kind'] == 'text' and normalized(b.get('text', ''))]
    body_sizes = [b.get('font_min', 0) for b in text
                  if len(b.get('text', '').split()) >= 30 and b.get('font_min', 0) > 0]
    body_size = median(body_sizes) if body_sizes else 9
    extent = fitz.Rect(blocks[0]['bbox']) if blocks else fitz.Rect()
    for block in blocks[1:]:
        extent |= fitz.Rect(block['bbox'])
    result = []
    for b in text:
        words = b.get('text', '').split()
        rect = fitz.Rect(b['bbox'])
        # Teaser headline is inside a promotional image with a page-link label.
        containers = [fitz.Rect(i['bbox']) for i in blocks if i['kind'] == 'image'
                      and fitz.Rect(i['bbox']).get_area() < extent.get_area() * .4
                      and (rect & fitz.Rect(i['bbox'])).get_area() >= rect.get_area()*.98]
        teaser = any(any(re.search(r'\bPAGE\s+(?:\d+|[IVX]+)\b', t.get('text', ''), re.I)
                         and (fitz.Rect(t['bbox']) & image).get_area() >= fitz.Rect(t['bbox']).get_area()*.98
                         for t in text) for image in containers)
        # Long standfirsts can use headline-sized fonts too. Keep this detector
        # conservative; it is a review guard, not proof of complete inventory.
        candidate = (2 <= len(words) <= 26 and (b.get('font_min', 0) >= body_size * 1.3
                     or b.get('font_max', 0) >= body_size * 1.8)
                     or b.get('layout_label') in ('doc_title', 'paragraph_title'))
        if candidate or teaser:
            result.append({'block_id': b['id'], 'text': b['text'],
                           'headline_candidate': candidate, 'teaser_hint': teaser})
    return result


def inventory_issues(blocks, articles, roles=None):
    issues = []
    for hint in headline_evidence(blocks):
        role = (roles or {}).get(str(hint['block_id']))
        if role in ('subheadline', 'kicker', 'masthead', 'teaser'):
            if any(headline_matches(hint['text'], title) for title in articles.values()):
                issues.append(f"Non-article {role} block {hint['block_id']} appears as a standalone story.")
            continue
        if role == 'other':
            continue
        matched = [ident for ident, title in articles.items() if headline_matches(hint['text'], title)]
        if hint['teaser_hint'] and matched:
            issues.append(f"Promotional teaser block {hint['block_id']} appears as an article: {matched}")
        elif hint['headline_candidate'] and not hint['teaser_hint'] and not matched:
            issues.append(f"Headline candidate block {hint['block_id']} is absent from inventory: {hint['text']}")
    return issues


def ownership_issues(blocks, owners, articles, roles=None):
    issues = inventory_issues(blocks, articles, roles)
    for hint in headline_evidence(blocks):
        if roles and roles.get(str(hint['block_id'])) in ('subheadline', 'kicker', 'masthead', 'teaser', 'other'):
            continue
        owner = owners[str(hint['block_id'])]
        if hint['headline_candidate'] and not hint['teaser_hint'] and (
                owner not in articles or not headline_matches(hint['text'], articles[owner])):
            issues.append(f"Headline block {hint['block_id']} has mismatched owner {owner}")
    for link in continuation_links(blocks):
        label, column = str(link['label']), str(link['column'])
        if owners[label] != owners[column]:
            issues.append(f'Continuation block {label} owner {owners[label]} differs from nearby column {column} owner {owners[column]}')
    return issues


def continuation_links(blocks):
    """Unambiguous explicit continuation labels and their nearest preceding column."""
    links = []
    for block in blocks:
        if not re.match(r'^\s*CONTINUED\s+ON\b', block.get('text', ''), re.I):
            continue
        rect = fitz.Rect(block['bbox'])
        above = []
        for other in blocks:
            if other['kind'] != 'text' or len(other.get('text', '').split()) < 8:
                continue
            r = fitz.Rect(other['bbox'])
            gap = rect.y0 - r.y1
            horizontal = min(rect.x1, r.x1) - max(rect.x0, r.x0)
            if 0 <= gap <= 40 and horizontal >= rect.width*.8:
                above.append((gap, other))
        if above:
            above.sort(key=lambda entry: entry[0])
            if len(above) > 1 and abs(above[0][0] - above[1][0]) < 1:
                continue
            nearest = above[0][1]
            links.append({'label': block['id'], 'column': nearest['id']})
    return links


def reconcile_continuations(blocks, owners, article_ids):
    """Apply only unambiguous native column links, retaining an audit of changes."""
    resolved = dict(owners)
    changes = []
    for link in continuation_links(blocks):
        label, column = str(link['label']), str(link['column'])
        owner = owners[column]
        if owner in article_ids and owners[label] != owner:
            changes.append({**link, 'previous_owner': owners[label], 'owner': owner,
                            'basis': 'explicit continuation beneath unambiguous native column'})
            resolved[label] = owner
    return resolved, changes


def ownership_schema(blocks, article_ids):
    return {'type': 'object', 'properties': {
        str(b['id']): {'type': 'string', 'enum': article_ids + EXCLUSIONS} for b in blocks},
        'required': [str(b['id']) for b in blocks], 'additionalProperties': False}


def parse_ownership(text, blocks, article_ids):
    import json
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate ownership key: ' + key)
            result[key] = value
        return result
    owners = json.loads(text, object_pairs_hook=unique_pairs)
    expected = {str(b['id']) for b in blocks}
    if not isinstance(owners, dict) or set(owners) != expected:
        actual = set(owners) if isinstance(owners, dict) else set()
        raise ValueError(f'Ownership coverage: missing={sorted(expected-actual)}, unknown={sorted(actual-expected)}')
    allowed = set(article_ids + EXCLUSIONS)
    if any(not isinstance(v, str) or v not in allowed for v in owners.values()):
        raise ValueError('Unknown article/exclusion owner.')
    for ident in article_ids:
        if not any(owners[str(b['id'])] == ident and b['kind'] == 'text' for b in blocks):
            raise ValueError('Article has no text blocks: ' + ident)
    return owners


def build_regions(blocks, owners, article_ids):
    """Greedily combine rectangles only when no foreign block is intersected."""
    foreign = {owner: [(b['id'], b['bbox']) for b in blocks
                       if owners[str(b['id'])] != owner] for owner in article_ids}
    conflict_cache = {}
    def conflicts(rect, owner):
        key = (owner, *rect)
        if key not in conflict_cache:
            conflict_cache[key] = [ident for ident, box in foreign[owner]
                if max(0, min(rect.x1, box[2])-max(rect.x0, box[0]))
                * max(0, min(rect.y1, box[3])-max(rect.y0, box[1])) > .01]
        return conflict_cache[key]

    result = {}
    for owner in article_ids:
        regions = [fitz.Rect(b['bbox']) for b in blocks if owners[str(b['id'])] == owner]
        for rect in regions:
            bad = conflicts(rect, owner)
            if bad:
                raise ValueError(f'{owner}: overlapping native blocks have different owners: {bad}')
        while True:
            choices = []
            for i in range(len(regions)):
                # Only nearby candidates are useful for compact article columns.
                # This bounds search work, not retained content or article count.
                a = regions[i]
                neighbors = sorted(range(i + 1, len(regions)), key=lambda j:
                    max(0, regions[j].x0-a.x1, a.x0-regions[j].x1)
                    + max(0, regions[j].y0-a.y1, a.y0-regions[j].y1))[:8]
                for j in neighbors:
                    union = regions[i] | regions[j]
                    absorbed = {i, j}
                    # A merged crop must also absorb every same-owner region it
                    # intersects. Otherwise two output crops repeat source text.
                    while True:
                        extra = {k for k, r in enumerate(regions) if k not in absorbed
                                 and (r & union).get_area() > .01}
                        if not extra:
                            break
                        for k in extra:
                            union |= regions[k]
                        absorbed |= extra
                    if not conflicts(union, owner):
                        cost = union.get_area() - sum(regions[k].get_area() for k in absorbed)
                        choices.append((cost, i, j, union, absorbed))
                        break
                if choices:
                    break
            if not choices:
                break
            _, i, j, union, absorbed = min(choices, key=lambda x: x[:3])
            regions = [r for k, r in enumerate(regions) if k not in absorbed] + [union]
        regions = disjoint_rectangles(regions)
        result[owner] = sorted(regions, key=lambda r: (r.y0, r.x0))
    return result


def disjoint_rectangles(rectangles):
    """Partition a union exactly; never enlarge crops to resolve an overlap."""
    accepted = []
    for rectangle in rectangles:
        pending = [fitz.Rect(rectangle)]
        for prior in accepted:
            next_parts = []
            for part in pending:
                hit = part & prior
                if hit.is_empty:
                    next_parts.append(part)
                    continue
                pieces = [(part.x0, part.y0, part.x1, hit.y0),
                          (part.x0, hit.y1, part.x1, part.y1),
                          (part.x0, hit.y0, hit.x0, hit.y1),
                          (hit.x1, hit.y0, part.x1, hit.y1)]
                next_parts.extend(fitz.Rect(p) for p in pieces if p[2] > p[0] and p[3] > p[1])
            pending = next_parts
        accepted.extend(pending)
    return accepted


def conflicting_pairs(blocks, owners, article_ids):
    """Report cross-owner crop overlaps, excluding pairs that are both excluded."""
    pairs = []
    for i, a in enumerate(blocks):
        for b in blocks[i+1:]:
            first, second = owners[str(a['id'])], owners[str(b['id'])]
            if first == second or not ({first, second} & set(article_ids)):
                continue
            if (fitz.Rect(a['bbox']) & fitz.Rect(b['bbox'])).get_area() > .01:
                pairs.append([a['id'], b['id']])
    return pairs


def overlap_components(blocks):
    """Connected overlapping source regions cannot be cropped as separate owners."""
    parent = list(range(len(blocks)))
    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i, a in enumerate(blocks):
        for j in range(i + 1, len(blocks)):
            if (fitz.Rect(a['bbox']) & fitz.Rect(blocks[j]['bbox'])).get_area() > .01:
                parent[root(j)] = root(i)
    groups = {}
    for i, block in enumerate(blocks):
        groups.setdefault(root(i), []).append(block['id'])
    return list(groups.values())


def render_article(preview, source, page_index, rectangles, label=None):
    """Keep source-relative column positions while leaving unrelated areas blank."""
    rects = [fitz.Rect(r) for r in rectangles]
    if not rects or any(r.is_empty or r.is_infinite for r in rects):
        raise ValueError('Article needs finite nonempty source regions.')
    bounds = fitz.Rect(rects[0])
    for rect in rects[1:]:
        bounds |= rect
    top = 36 if label else 12
    dest = preview.new_page(width=bounds.width+24, height=bounds.height+top+12)
    if label:
        dest.insert_text((12, 15), label, fontsize=6)
    for rect in rects:
        target = fitz.Rect(rect.x0-bounds.x0+12, rect.y0-bounds.y0+top,
                           rect.x1-bounds.x0+12, rect.y1-bounds.y0+top)
        dest.show_pdf_page(target, source, page_index, clip=rect)
    return dest
