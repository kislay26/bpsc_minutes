"""Learned page regions with OCR, expressed in original PDF coordinates."""
import os
from pathlib import Path
import json
import hashlib

import fitz


def extract_raster_blocks(page):
    from native_layout import ocr_words
    cache = Path(__file__).resolve().parent / '.model-cache'
    for name, folder in [('PADDLE_PDX_CACHE_HOME', 'paddlex'), ('HF_HOME', 'huggingface'),
                         ('PADDLE_HOME', 'paddle')]:
        os.environ.setdefault(name, str(cache / folder))
    os.environ.setdefault('PADDLE_PDX_MODEL_SOURCE', 'BOS')
    os.environ.setdefault('PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK', 'True')
    from paddleocr import LayoutDetection
    import numpy as np
    scale = 2000 / page.rect.width
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
    image = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, 3)
    model_name = 'PP-DocLayout_plus-L'
    digest = hashlib.sha256(pix.samples + model_name.encode()).hexdigest()
    folder = cache / 'layout-results'
    folder.mkdir(parents=True, exist_ok=True)
    saved = folder / (digest + '.json')
    if not saved.exists():
        model = LayoutDetection(model_name=model_name, device='cpu', cpu_threads=2,
                                enable_mkldnn=False)
        result = next(iter(model.predict(image[:, :, ::-1].copy(), batch_size=1, layout_nms=True)))
        result.save_to_json(str(saved))
    data = json.loads(saved.read_text(encoding='utf-8'))
    detections = data.get('res', data)['boxes']
    blocks = []
    for detection in detections:
        rect = fitz.Rect([float(v)/scale for v in detection['coordinate']]) & page.rect
        if rect.is_empty or rect.is_infinite:
            raise ValueError('Layout detector returned invalid geometry.')
        blocks.append({'id': len(blocks), 'kind': 'image' if detection['label'] in
                       ('image', 'chart', 'table', 'figure') else 'text',
                       'bbox': list(rect), 'text': '', 'font_min': 0, 'font_max': 0,
                       'layout_label': detection['label'], 'layout_score': float(detection['score']),
                       'geometry_source': model_name, 'text_source': 'tesseract_ocr'})
    words = ocr_words(page)
    if not words or not blocks:
        raise ValueError('Raster extraction returned no text or layout regions.')
    for word in words:
        point = fitz.Point(word['cx'], word['cy'])
        candidates = [b for b in blocks if fitz.Rect(b['bbox']).contains(point)]
        if candidates:
            # Assign a word once, preferring the smallest text region over image panels.
            chosen = min(candidates, key=lambda b: (b['kind'] != 'text', fitz.Rect(b['bbox']).get_area()))
            chosen['text'] += (' ' if chosen['text'] else '') + word['text']
        else:
            # Never silently drop OCR words that the detector missed.
            blocks.append({'id': len(blocks), 'kind': 'text', 'bbox': word['bbox'],
                           'text': word['text'], 'font_min': 0, 'font_max': 0,
                           'geometry_source': 'unmatched_ocr_word', 'text_source': 'tesseract_ocr'})
    return blocks
